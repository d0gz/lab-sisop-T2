#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/slab.h>    // For kmalloc/kfree
#include <linux/string.h>  // For string functions (strlen, strncpy, strcmp)
#include <linux/errno.h>   // For error codes (ENOENT, EPERM, ENODATA, EALREADY)
#include <linux/kernel.h>  // Provides min() and other basic utilities

// --- 1. Constants and Structure Definitions ---
// --- 1.5. Module Parameters for Bounded Queue ---
static int queue_capacity = 10;
static int max_msg_bytes = 128;

// Define the module parameters for loading via modprobe
module_param(queue_capacity, int, 0); 
module_param(max_msg_bytes, int, 0); 
MODULE_PARM_DESC(queue_capacity, "Maximum messages per subscription queue (default 10).");
MODULE_PARM_DESC(max_msg_bytes, "Maximum message bytes (default 128).");
// ------------------------------------------------
#define MSG_SIZE 128
#define NAME_SIZE 32

// A. Message Structure
struct message_s {
    struct list_head link;
    char message[MSG_SIZE];
    short size;
};

// B. Process Subscription Structure (Duplicated per Topic)
struct process_subscription {
    struct list_head process_link;      // Links this subscription instance into the topic's list.
    struct list_head message_list_head; // Anchors the *separate, unique* message queue.

     // NEW FIELDS for Bounded Queue (THESE MUST BE PRESENT)
    int current_count; // Messages currently in the queue
    int capacity;      // Max messages allowed
    
    char name[NAME_SIZE];
    int pid;
};

// C. Topic Structure
struct topic {
    struct list_head topic_link;             // Links this topic into the Global Topic List
    struct list_head subscription_list_head; // Anchors the list of struct process_subscription objects.
    
    char topic_name[NAME_SIZE];
};

// --- 2. Global Anchor and Function Prototypes ---

// Global list head for all topics
struct list_head global_topic_list_head; 

// Prototypes (moved from the header to the implementation file)
static struct topic *find_topic(const char *tname);
static struct process_subscription *find_subscription(struct topic *t, int pid);

int topic_subscribe_process(int pid, const char *pname, const char *tname);
int topic_unsubscribe_process(int pid, const char *tname);
int topic_publish_message(const char *tname, const char *data);
int topic_fetch_message(int pid, const char *tname, char *buffer, size_t max_len);
void topic_cleanup_all(void);


// --- 3. Helper Functions ---

// Helper: Find a topic by name
static struct topic *find_topic(const char *tname) {
    struct topic *t_entry;
    
    list_for_each_entry(t_entry, &global_topic_list_head, topic_link) {
        if (strcmp(t_entry->topic_name, tname) == 0) {
            return t_entry;
        }
    }
    return NULL;
}

// Helper: Find a specific subscription (pid) within a topic
static struct process_subscription *find_subscription(struct topic *t, int pid) {
    struct process_subscription *p_entry;
    
    list_for_each_entry(p_entry, &t->subscription_list_head, process_link) {
        if (p_entry->pid == pid) {
            return p_entry;
        }
    }
    return NULL;
}


// --- 4. Core PubSub Logic ---

int topic_subscribe_process(int pid, const char *pname, const char *tname) {
    struct topic *t = find_topic(tname);
    struct process_subscription *new_sub;
    
    // 1. Create Topic if it doesn't exist
    if (!t) {
        printk(KERN_INFO "Topic %s not found. Creating it.\n", tname);
        t = kmalloc(sizeof(*t), GFP_KERNEL);
        if (!t) return -ENOMEM;
        
        strncpy(t->topic_name, tname, NAME_SIZE - 1);
        t->topic_name[NAME_SIZE - 1] = '\0';
        INIT_LIST_HEAD(&t->subscription_list_head);
        list_add_tail(&t->topic_link, &global_topic_list_head);
    }
    
    // 2. Check for duplicate subscription
    if (find_subscription(t, pid)) {
        printk(KERN_INFO "Process %d is already subscribed to topic %s.\n", pid, tname);
        return -EALREADY;
    }

    // 3. Create the unique subscription instance (MODIFIED)
    new_sub = kmalloc(sizeof(*new_sub), GFP_KERNEL);
    if (!new_sub) return -ENOMEM;
    
    // Set capacity and initialize count
    new_sub->capacity = queue_capacity;  // Use the module parameter value!
    new_sub->current_count = 0;          // Queue is empty
    
    new_sub->pid = pid;
    strncpy(new_sub->name, pname, NAME_SIZE - 1);
    new_sub->name[NAME_SIZE - 1] = '\0';
    INIT_LIST_HEAD(&new_sub->message_list_head); // Initialize the private message queue!
    
    // 4. Link the new subscription to the topic
    list_add_tail(&new_sub->process_link, &t->subscription_list_head);
    
    printk(KERN_INFO "Process %s (PID %d) subscribed to %s.\n", pname, pid, tname);
    return 0;
}

int topic_unsubscribe_process(int pid, const char *tname) {
    struct topic *t = find_topic(tname);
    struct process_subscription *sub_to_del;
    struct message_s *msg_item, *tmp;

    if (!t) return -ENOENT;

    sub_to_del = find_subscription(t, pid);
    if (!sub_to_del) return -ENOENT;

    // 1. Clean up and free the entire message queue
    list_for_each_entry_safe(msg_item, tmp, &sub_to_del->message_list_head, link) {
        list_del(&msg_item->link);
        kfree(msg_item);
    }
    
    // 2. Remove the subscription instance from the topic's list and free it
    list_del(&sub_to_del->process_link);
    kfree(sub_to_del);

    // Optional: If subscription_list_head is empty, you could delete the topic here too.
    
    printk(KERN_INFO "Process %d unsubscribed from %s.\n", pid, tname);
    return 0;
}

int topic_publish_message(const char *tname, const char *data) {
    struct topic *t = find_topic(tname);
    struct process_subscription *p_entry;
    int msg_len;
    
    if (!t) {
        printk(KERN_ERR "PUBLISH ERROR: Topic %s does not exist.\n", tname);
        return -ENOENT;
    }

    // Use strlen cautiously in kernel context, ensure data is valid C string
    msg_len = strlen(data); 

    if (list_empty(&t->subscription_list_head)) {
        printk(KERN_INFO "Topic %s has no subscribers. Message discarded.\n", tname);
        return 0;
    }

    // Iterate through all subscriptions
    list_for_each_entry(p_entry, &t->subscription_list_head, process_link) {
        
        // 1. BOUNDED QUEUE CHECK: Remove oldest if capacity is reached
        if (p_entry->current_count >= p_entry->capacity) {
            struct message_s *oldest_msg = list_first_entry(&p_entry->message_list_head, struct message_s, link);
            
            list_del(&oldest_msg->link);
            kfree(oldest_msg);
            // DO NOT DECREMENT current_count, as we are immediately replacing it!
            
            printk(KERN_INFO "Subscription PID %d: Queue full (Cap=%d). Dropped oldest message.\n", 
                   p_entry->pid, p_entry->capacity);
        } else {
            // Only increment count if we actually add a NEW message (not replacing one)
            p_entry->current_count++;
        }
        
        // 2. Message Allocation and Copy (MODIFIED for MAX_MSG_BYTES)
        struct message_s *new_msg = kmalloc(sizeof(*new_msg), GFP_KERNEL);
        // ... error check ...

        // Copy message data (using the max_msg_bytes parameter)
        // Ensure data is not longer than the user-defined limit OR the struct size
        new_msg->size = min((size_t)max_msg_bytes, (size_t)msg_len);
        strncpy(new_msg->message, data, new_msg->size);
        new_msg->message[new_msg->size] = '\0';
        
        // 3. Add to the process's *private* message list (at the tail)
        list_add_tail(&new_msg->link, &p_entry->message_list_head);
        
        // If we replaced an item, current_count remains the same (at capacity).
        // If we added a new item, current_count was incremented above.
    }

    printk(KERN_INFO "Message published to %s.\n", tname);
    return 0;
}

int topic_fetch_message(int pid, const char *tname, char *buffer, size_t max_len) {
    struct topic *t = find_topic(tname);
    struct process_subscription *sub;
    struct message_s *msg_to_read;
    
    if (!t) return -ENOENT;

    sub = find_subscription(t, pid);
    if (!sub) {
        printk(KERN_ERR "FETCH ERROR: Process %d is not subscribed to %s.\n", pid, tname);
        return -EPERM;
    }

    if (list_empty(&sub->message_list_head)) {
        printk(KERN_INFO "Process %d has no messages in topic %s.\n", pid, tname);
        return -ENODATA;
    }

    // 1. Get the first (oldest) entry in the private queue (FIFO read)
    msg_to_read = list_first_entry(&sub->message_list_head, struct message_s, link);
    
    // 2. Copy the message data to the user buffer
    size_t copy_len = min((size_t)msg_to_read->size, max_len - 1); // min(actual_msg_size, available_buffer_space - 1 for NULL)
    strncpy(buffer, msg_to_read->message, copy_len);
    buffer[copy_len] = '\0'; // Ensure null termination
    
    // 3. Remove the message from the list and free memory
    list_del(&msg_to_read->link);
    kfree(msg_to_read);

    // DECREMENT THE COUNT
    sub->current_count--;

    printk(KERN_INFO "Process %d fetched message from %s - Message: %s \n", pid, tname, msg_to_read->message);
    return 0;
}

// --- 5. Module Initialization and Cleanup ---

void topic_cleanup_all(void) {
    struct topic *t_entry, *t_tmp;
    struct process_subscription *sub_entry, *sub_tmp;
    struct message_s *msg_item, *msg_tmp;

    // 1. Iterate safely through all topics
    list_for_each_entry_safe(t_entry, t_tmp, &global_topic_list_head, topic_link) {
        printk(KERN_INFO "Cleaning up Topic: %s\n", t_entry->topic_name);

        // 2. Iterate safely through all subscriptions in this topic
        list_for_each_entry_safe(sub_entry, sub_tmp, &t_entry->subscription_list_head, process_link) {

            // 3. Clean up and free the entire message queue for this subscription
            list_for_each_entry_safe(msg_item, msg_tmp, &sub_entry->message_list_head, link) {
                list_del(&msg_item->link);
                kfree(msg_item);
            }
            
            // 4. Remove the subscription from the topic and free it
            list_del(&sub_entry->process_link);
            kfree(sub_entry);
        }

        // 5. Remove the topic from the global list and free it
        list_del(&t_entry->topic_link);
        kfree(t_entry);
    }
    printk(KERN_INFO "PubSub system fully cleaned up.\n");
}


static int __init pubsub_init(void) {
    // Initialize the global anchor list head
    INIT_LIST_HEAD(&global_topic_list_head);
    printk(KERN_INFO "PubSub Module: Initialized global topic list.\n");
    
    // Example usage in the init function (for testing):
    
    topic_subscribe_process(101, "ProcA", "News");
    topic_subscribe_process(101, "ProcA", "Sports"); // Same process, different subscription instance
    topic_subscribe_process(102, "ProcB", "News");

   // topic_publish_message("News", "Breaking News!");
    topic_publish_message("News", "1RAMON DIAZ COLORADO!");
    topic_publish_message("News", "2RAMON DIAZ COLORADO!");
    topic_publish_message("News", "3RAMON DIAZ COLORADO!");
    topic_publish_message("News", "4RAMON DIAZ COLORADO!");
    topic_publish_message("News", "5RAMON DIAZ COLORADO!");
    topic_publish_message("News", "6RAMON DIAZ COLORADO!");
    topic_publish_message("Sports", "Game Results!");

    char buf[128];
   // topic_fetch_message(101, "News", buf, sizeof(buf)); // Reads "Breaking News!"
    topic_fetch_message(101, "Sports", buf, sizeof(buf)); // Reads "Game Results!"
    topic_fetch_message(102, "News", buf, sizeof(buf)); 
   // topic_fetch_message(101, "News", buf, sizeof(buf)); 
    topic_fetch_message(102, "News", buf, sizeof(buf)); 
    topic_fetch_message(102, "News", buf, sizeof(buf)); 
    topic_fetch_message(102, "News", buf, sizeof(buf)); 
    topic_fetch_message(102, "News", buf, sizeof(buf)); 
    topic_fetch_message(102, "News", buf, sizeof(buf)); 
    
    
    return 0;
}

static void __exit pubsub_exit(void) {
    // Crucial step: Free all allocated memory before the module unloads
    topic_cleanup_all();
    printk(KERN_INFO "PubSub Module: Unloaded and cleaned up all resources.\n");
}

module_init(pubsub_init);
module_exit(pubsub_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("AI Assistant");
MODULE_DESCRIPTION("Kernel-level Publish/Subscribe System with Duplicated Subscriptions.");